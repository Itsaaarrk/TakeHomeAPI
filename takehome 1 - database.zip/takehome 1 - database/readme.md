# Senior Software Engineer (Database Design) - Take-Home Assignment

## Overview
This project presents a relational database schema designed using Microsoft SQL Server to store product information along with hierarchical packaging and their contained items. The design emphasizes normalization, data integrity, and the ability to query nested (hierarchical) packaging using recursive queries.

## Database Schema Design

### Tables and Relationships

1. Product Table
   - Purpose: Stores product details.
   - Columns:
     - `ProductID` (Primary Key): Unique identifier for the product.
     - `ProductName`: The name of the product.
     - `Description`: Optional details about the product.

2. Packaging Table
   - Purpose: Stores packaging information that can include nested packaging.
   - Columns:
     - `PackagingID` (Primary Key): Unique identifier for each packaging record.
     - `ProductID` (Foreign Key): Links the packaging record to a product.
     - `ParentPackagingID` (Foreign Key, nullable): Self-referencing column to support nested packaging.
     - `PackagingType`: Specifies the type of packaging (e.g., box, packet, pallet).
     - `PackagingName`: Optional descriptive name for the packaging.
   - Relationships:
     - One Product can have multiple Packaging records.
     - Packaging may contain other Packaging records (self-referencing relationship).

3. Item Table
   - Purpose: Stores items that reside inside a packaging unit.
   - Columns:
     - `ItemID` (Primary Key): Unique identifier for each item.
     - `PackagingID` (Foreign Key): Connects the item to its packaging.
     - `ItemName`: The name of the item.

### Key Features
- Hierarchical Packaging Structure:  
  The self-referencing foreign key (`ParentPackagingID`) in the Packaging table enables modeling of an arbitrarily nested packaging structure. This allows you to represent a scenario like a box containing multiple sub-boxes or packets, each possibly containing further nested packaging.

- Data Integrity:  
  Foreign key constraints ensure that:
  - Each packaging record is linked to a valid product.
  - Each nested packaging record refers to an existing parent packaging.
  - Items are associated with a valid packaging record.
  
- Efficient Querying:  
  Recursive Common Table Expressions (CTEs) are used to traverse the nested packaging structure. Example queries are provided to fetch:
  - A product along with all its packaging levels.
  - Packaging that contains a specific item (e.g., "Screwdriver").

- Indexing:  
  Indexes are applied on key columns such as `ProductID`, `ParentPackagingID`, and `PackagingID` in the Item table to enhance query performance, especially for recursive and join queries.

## Explanation of the ERD / Database Diagram

The ERD (Entity-Relationship Diagram) is an additional deliverable that visually summarizes the database schema:

- Product Entity:  
  Shows the product details and its primary key, which other tables reference.
  
- Packaging Entity:  
  Displays the packaging records with both the `ProductID` (linking to the Product table) and `ParentPackagingID` (establishing the self-referencing relationship). This diagram clearly illustrates the one-to-many relationship between products and packaging, as well as the recursive relationship within packaging to represent hierarchical data.
  
- Item Entity:  
  Demonstrates the items stored in packaging, showing a one-to-many relationship between Packaging and Item.

Note: Database diagrams generated in SQL Server Management Studio (SSMS) are acceptable. They capture the table structure and relationships (including primary keys, foreign keys, and self-references) and complement the schema design by providing a visual summary.

For instance, the attached SSMS diagram image shows:
- The Product table with `ProductID`, `ProductName`, and `Description`.
- The Packaging table with its fields and two relationships: one with Product (via `ProductID`) and a self-referencing relationship through `ParentPackagingID`.
- The Item table which links back to the Packaging table (via `PackagingID`).

This visual aid helps reviewers quickly understand the structure and logic of the database design.

## How to Execute on SSMS

1. Open SSMS and Connect:  
   Launch SQL Server Management Studio and connect to your SQL Server instance.

2. Create a New Query:  
   Click on the "New Query" button.

3. Run Schema Creation Script:  
   Paste and execute the SQL script for schema creation.

4. Insert Sample Data:  
   Execute the sample data insertion script to populate the tables.

5. Execute Provided Queries:  
   Run the recursive CTE queries to retrieve the product packaging hierarchy and the item-based queries to verify the relationships.

6. Review the Results:  
   Check the results in the SSMS results pane to ensure accurate data retrieval.



