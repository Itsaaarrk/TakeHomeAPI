USE TakeHomeAPI
-- Insert sample product
INSERT INTO dbo.Products (ProductName, Description)
VALUES ('Self adjusting table', 'Adjustable table with nested packaging structure');
DECLARE @ProductID INT = SCOPE_IDENTITY();

-- Insert main packaging (e.g., main box for the product)
INSERT INTO dbo.Packagings (ProductID, ParentPackagingID, PackagingType, PackagingName)
VALUES (@ProductID, NULL, 'Box', 'Main Box');
DECLARE @MainBox INT = SCOPE_IDENTITY();

-- Insert nested packaging inside the main box:
-- Package 1: Box containing the table top.
INSERT INTO dbo.Packagings (ProductID, ParentPackagingID, PackagingType, PackagingName)
VALUES (@ProductID, @MainBox, 'Box', 'Table Top Box');
DECLARE @PackageTableTop INT = SCOPE_IDENTITY();

-- Package 2: Box containing the table legs.
INSERT INTO dbo.Packagings (ProductID, ParentPackagingID, PackagingType, PackagingName)
VALUES (@ProductID, @MainBox, 'Box', 'Table Legs Box');
DECLARE @PackageTableLegs INT = SCOPE_IDENTITY();

-- Package 3: Packet containing a screwdriver and a nested packet.
INSERT INTO dbo.Packagings (ProductID, ParentPackagingID, PackagingType, PackagingName)
VALUES (@ProductID, @MainBox, 'Packet', 'Tool Packet');
DECLARE @PacketTool INT = SCOPE_IDENTITY();

-- Package 4: Nested packet within Package 3 that contains screws.
INSERT INTO dbo.Packagings (ProductID, ParentPackagingID, PackagingType, PackagingName)
VALUES (@ProductID, @PacketTool, 'Packet', 'Screws Packet');
DECLARE @PacketScrews INT = SCOPE_IDENTITY();

-- Insert items into their respective packaging:
INSERT INTO dbo.Items (PackagingID, ItemName)
VALUES (@PackageTableTop, 'Table top');

INSERT INTO dbo.Items (PackagingID, ItemName)
VALUES (@PackageTableLegs, 'Table legs');

INSERT INTO dbo.Items (PackagingID, ItemName)
VALUES (@PacketTool, 'Screwdriver');

INSERT INTO dbo.Items (PackagingID, ItemName)
VALUES (@PacketScrews, 'Screws');
GO
