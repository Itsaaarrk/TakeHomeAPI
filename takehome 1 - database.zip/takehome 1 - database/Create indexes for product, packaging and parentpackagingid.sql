-- Create Indexes for improved performance
CREATE INDEX IDX_Packaging_ProductID ON dbo.Packaging(ProductID);
CREATE INDEX IDX_Packaging_ParentPackagingID ON dbo.Packaging(ParentPackagingID);
CREATE INDEX IDX_Item_PackagingID ON dbo.Item(PackagingID);
GO
