WITH PackagingHierarchy AS (
    -- Anchor member: select top-level packaging for the product
    SELECT 
        PackagingID,
        ProductID,
        ParentPackagingID,
        PackagingType,
        PackagingName,
        1 AS Level
    FROM dbo.Packaging
    WHERE ProductID = 1 AND ParentPackagingID IS NULL
    UNION ALL
    -- Recursive member: join on ParentPackagingID to traverse nested packaging
    SELECT 
        p.PackagingID,
        p.ProductID,
        p.ParentPackagingID,
        p.PackagingType,
        p.PackagingName,
        ph.Level + 1 AS Level
    FROM dbo.Packaging p
    INNER JOIN PackagingHierarchy ph
        ON p.ParentPackagingID = ph.PackagingID
)
SELECT * 
FROM PackagingHierarchy
ORDER BY Level, PackagingID;
GO
