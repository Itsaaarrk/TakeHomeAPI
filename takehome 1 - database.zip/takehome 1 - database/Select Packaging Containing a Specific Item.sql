--Select Packaging Containing a Specific Item
SELECT 
    p.PackagingID,
    p.PackagingType,
    p.PackagingName,
    i.ItemID,
    i.ItemName
FROM dbo.Packaging p
INNER JOIN dbo.Item i
    ON p.PackagingID = i.PackagingID
WHERE i.ItemName = 'Screwdriver';
GO
