-- Drop tables in reverse order to avoid dependency errors
IF OBJECT_ID('dbo.Item', 'U') IS NOT NULL DROP TABLE dbo.Item;
IF OBJECT_ID('dbo.Packaging', 'U') IS NOT NULL DROP TABLE dbo.Packaging;
IF OBJECT_ID('dbo.Product', 'U') IS NOT NULL DROP TABLE dbo.Product;
GO

-- Create Product table
CREATE TABLE dbo.Product (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Description VARCHAR(255) NULL
);
GO

-- Create Packaging table  
CREATE TABLE dbo.Packaging (
    PackagingID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    ParentPackagingID INT NULL,  -- Self-reference for nested packaging
    PackagingType VARCHAR(50) NOT NULL,  -- e.g., Box, Packet, Pallet, Wrapper
    PackagingName VARCHAR(100) NULL,  -- Optional descriptive name
    CONSTRAINT FK_Packaging_Product FOREIGN KEY (ProductID)
        REFERENCES dbo.Product(ProductID)
        ON DELETE CASCADE,   -- Cascade deletion from product to packaging
    CONSTRAINT FK_Packaging_Parent FOREIGN KEY (ParentPackagingID)
        REFERENCES dbo.Packaging(PackagingID)
        ON DELETE NO ACTION    -- Avoid cascade deletion on self-reference
);
GO

-- Create Item table
CREATE TABLE dbo.Item (
    ItemID INT IDENTITY(1,1) PRIMARY KEY,
    PackagingID INT NOT NULL,
    ItemName VARCHAR(100) NOT NULL,
    CONSTRAINT FK_Item_Packaging FOREIGN KEY (PackagingID)
        REFERENCES dbo.Packaging(PackagingID)
        ON DELETE CASCADE   -- Cascade deletion from packaging to item
);
GO
